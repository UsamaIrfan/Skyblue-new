export const colors = {
  Black: "#000000",
  Blue: "#2190f8",
  Red: "#ee342b",
  Green: "#6ac70f",
  Grey: "#8e8e8e",
  DarkGrey: '#474747'
};
